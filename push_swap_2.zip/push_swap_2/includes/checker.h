/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/23 15:15:22 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 17:30:14 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CHECKER_H
# define CHECKER_H

# include "../get_next_line/get_next_line.h"

# include <unistd.h>
# include <stdlib.h>
# include <stdio.h>

// Definitions
# define MAXINT 2147483647
# define MININT -2147483648

// Stack struct
typedef struct s_stack
{
	int				value;
	struct s_stack	*next;
}	t_stack;

// Extremums struct
typedef struct s_extremums
{
	int	max_a;
	int	min_a;
	int	max_b;
	int	min_b;
}	t_extremums;

// Moves struct
typedef struct s_moves
{
	int	price;
	int	sa;
	int	sb;
	int	ss;
	int	pa;
	int	pb;
	int	ra;
	int	rb;
	int	rr;
	int	rra;
	int	rrb;
	int	rrr;
}	t_moves;

// Stacks + Moves + Extrumums struct
typedef struct s_stacks
{
	struct s_stack		*stack_a;
	struct s_stack		*stack_b;
	struct s_moves		*moves;
	struct s_moves		*cheapest;
	struct s_extremums	*extremums;
}	t_stacks;

// Check args
void			ft_check_args(int argc, char **argv);
char			**ft_split(char const *s, char c);

// Check dup
void			ft_check_dup(t_stack *stack);

// Create Stack
t_stack			*ft_create_stack(int argc, char **argv);

// Swap
void			ft_sa_checker(t_stacks *stacks);
void			ft_sb_checker(t_stacks *stacks);
void			ft_ss_checker(t_stacks *stacks);

// Push
void			ft_pa_checker(t_stacks *stacks);
void			ft_pb_checker(t_stacks *stacks);

// Rotate
void			ft_ra_checker(t_stacks *stacks);
void			ft_rb_checker(t_stacks *stacks);
void			ft_rr_checker(t_stacks *stacks);

// Reverse Rotate
void			ft_rra_checker(t_stacks *stacks);
void			ft_rrb_checker(t_stacks *stacks);
void			ft_rrr_checker(t_stacks *stacks);

// Error
void			ft_error(char *s);

// Free
void			ft_free_split_and_exit(char **split, int exitFlag);
void			ft_free_stacks_checker(t_stacks *stacks);
void			ft_free_nodes(t_stack *stack);
void			ft_free_all_and_exit(char **split, t_stack *stack);
void			ft_free_stacks_op(t_stacks *stacks, char *op);

// 7. Other utils
long long int	ft_atoll(const char *str);
int				ft_atoi(const char *nptr);
void			ft_putstr(char *s);
void			*ft_memset(void *s, int c, size_t n);
int				ft_strncmp(const char *s1, const char *s2, size_t n);

#endif