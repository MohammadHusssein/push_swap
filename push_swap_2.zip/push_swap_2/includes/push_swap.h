/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 13:51:22 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 17:40:50 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PUSH_SWAP_H
# define PUSH_SWAP_H

# include <unistd.h>
# include <stdlib.h>
# include <stdio.h>

// Definitions
# define MAXINT 2147483647
# define MININT -2147483648

// Stack struct
typedef struct s_stack
{
	int				value;
	struct s_stack	*next;
}	t_stack;

// Extremums struct
typedef struct s_extremums
{
	int	max_a;
	int	min_a;
	int	max_b;
	int	min_b;
}	t_extremums;

// Moves struct
typedef struct s_moves
{
	int	price;
	int	sa;
	int	sb;
	int	ss;
	int	pa;
	int	pb;
	int	ra;
	int	rb;
	int	rr;
	int	rra;
	int	rrb;
	int	rrr;
}	t_moves;

// Stacks + Moves + Extrumums struct
typedef struct s_stacks
{
	struct s_stack		*stack_a;
	struct s_stack		*stack_b;
	struct s_moves		*moves;
	struct s_moves		*cheapest;
	struct s_extremums	*extremums;
}	t_stacks;

// 1. Checking input

// Check args
void			ft_check_args(int argc, char **argv);
char			**ft_split(char const *s, char c);

// Check dup
void			ft_check_dup(t_stack *stack);

// 2. Stack

// Create Stack
t_stack			*ft_create_stack(int argc, char **argv);

// Stack utils
void			ft_print_stack(t_stack *stack);
int				ft_stack_size(t_stack *stack);

// 3. Operations

// Swap
void			ft_sa(t_stacks *stacks, int print);
void			ft_sb(t_stacks *stacks, int print);
void			ft_ss(t_stacks *stacks);

// Push
void			ft_pa(t_stacks *stacks);
void			ft_pb(t_stacks *stacks);

// Rotate
void			ft_ra(t_stacks *stacks, int print);
void			ft_rb(t_stacks *stacks, int print);
void			ft_rr(t_stacks *stacks);

// Reverse Rotate
void			ft_rra(t_stacks *stacks, int print);
void			ft_rrb(t_stacks *stacks, int print);
void			ft_rrr(t_stacks *stacks);

// 4. Algorithm

void			ft_sort(t_stacks *stacks);

// Small number
void			ft_sort_three(t_stacks *stacks);
void			ft_sort_four(t_stacks *stacks);
void			ft_sort_five(t_stacks *stacks);

// Small number utils
int				ft_min_pos(t_stack *stack);
void			ft_push_pos(t_stacks *stacks, t_stack **stack_a, int pos);

// Big number
void			ft_sort_big(t_stacks *stacks);

// Big number utils
void			ft_update_extremums(t_stacks *stacks, int stack);
void			ft_calculate_cheapest(t_stacks *stacks);
void			ft_move_cheapest(t_stacks *stacks);

// Update extremums
void			ft_update_min_a(t_stacks *stacks);
void			ft_update_max_a(t_stacks *stacks);
void			ft_update_min_b(t_stacks *stacks);
void			ft_update_max_b(t_stacks *stacks);

// Calculate Cheapest
void			ft_price_to_top_a(t_stacks *stacks, int pos);
void			ft_new_extremum_price(t_stacks *stacks);
void			ft_price_in_b(t_stacks *stacks, int value);
void			ft_optimise_moves(t_stacks *stacks);
void			ft_check_cost(t_stacks *stacks, int i);

// Push to stack a
void			ft_push_to_stack_a(t_stacks *stacks);
void			ft_new_min_a(t_stacks *stacks);
void			ft_new_max_a(t_stacks *stacks);
void			ft_new_element_a(t_stacks *stacks, t_stack *head_b);
int				ft_find_pos_a(t_stacks *stacks, int value);
void			ft_do_moves_a(t_stacks *stacks, int maxflag);

// 5. Error
void			ft_error(char *s);

// 6. Free
void			ft_free_split_and_exit(char **split, int exitFlag);
void			ft_free_stacks(t_stacks *stacks);
void			ft_free_nodes(t_stack *stack);
void			ft_free_all_and_exit(char **split, t_stack *stack);

// 7. Other utils
long long int	ft_atoll(const char *str);
int				ft_atoi(const char *nptr);
void			ft_putstr(char *s);
void			*ft_memset(void *s, int c, size_t n);

#endif