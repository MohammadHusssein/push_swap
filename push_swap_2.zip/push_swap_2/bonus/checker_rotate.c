/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_rotate.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/23 16:33:59 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 16:41:09 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/checker.h"

void	ft_ra_checker(t_stacks *stacks)
{
	t_stack	*last;

	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL)
		return ;
	last = stacks->stack_a;
	while (last->next != NULL)
		last = last->next;
	last->next = stacks->stack_a;
	stacks->stack_a = stacks->stack_a->next;
	last->next->next = NULL;
}

void	ft_rb_checker(t_stacks *stacks)
{
	t_stack	*last;

	if (stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	last = stacks->stack_b;
	while (last->next != NULL)
		last = last->next;
	last->next = stacks->stack_b;
	stacks->stack_b = stacks->stack_b->next;
	last->next->next = NULL;
}

void	ft_rr_checker(t_stacks *stacks)
{
	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL
		|| stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	ft_ra_checker(stacks);
	ft_rb_checker(stacks);
}
