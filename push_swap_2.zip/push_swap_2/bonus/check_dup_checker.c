/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_dup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 16:08:27 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:43 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

// Checks for duplicates
void	ft_check_dup(t_stack *stack)
{
	t_stack	*current;
	t_stack	*cmp;
	int		count;	

	if (stack->next == NULL)
		return ;
	current = stack;
	while (current != NULL)
	{
		count = 0;
		cmp = stack;
		while (cmp != NULL)
		{
			if (cmp->value == current->value)
				count++;
			cmp = cmp->next;
		}
		if (count != 1)
		{
			ft_free_nodes(stack);
			ft_error("Error\n");
		}
		current = current->next;
	}
}
	