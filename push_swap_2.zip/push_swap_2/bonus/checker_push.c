/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_push.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/23 16:33:50 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 16:41:53 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/checker.h"

void	ft_pa_checker(t_stacks *stacks)
{
	t_stack	*tmp;

	if (stacks->stack_b == NULL)
		return ;
	tmp = stacks->stack_a;
	stacks->stack_a = stacks->stack_b;
	stacks->stack_b = stacks->stack_b->next;
	stacks->stack_a->next = tmp;
}

void	ft_pb_checker(t_stacks *stacks)
{
	t_stack	*tmp;

	if (stacks->stack_a == NULL)
		return ;
	tmp = stacks->stack_b;
	stacks->stack_b = stacks->stack_a;
	stacks->stack_a = stacks->stack_a->next;
	stacks->stack_b->next = tmp;
}
