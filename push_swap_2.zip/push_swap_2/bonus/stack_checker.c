/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 15:55:00 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 16:03:14 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

t_stack	*ft_create_node(int value)
{
	t_stack	*new_node;

	new_node = (t_stack *)malloc(sizeof(t_stack));
	if (!new_node)
		return (NULL);
	new_node->value = value;
	new_node->next = NULL;
	return (new_node);
}

int	ft_add_node(t_stack **head, t_stack *node)
{
	t_stack	*current;

	if (node == NULL)
		return (-1);
	if (head == NULL || *head == NULL)
		*head = node;
	else
	{
		current = *head;
		while (current != NULL && current->next != NULL)
			current = current->next;
		current->next = node;
	}
	return (1);
}

t_stack	*ft_create_stack(int argc, char **argv)
{
	int		i;
	char	**split;
	int		j;
	t_stack	*head_a;

	head_a = NULL;
	i = 1;
	while (i < argc)
	{
		split = ft_split(argv[i], ' ');
		if (split == NULL)
			ft_free_split_and_exit(split, 1);
		j = 0;
		while (split[j])
		{
			if (ft_add_node(&head_a, ft_create_node(ft_atoi(split[j]))) == -1)
				ft_free_all_and_exit(split, head_a);
			j++;
		}
		ft_free_split_and_exit(split, 0);
		i++;
	}
	return (head_a);
}
