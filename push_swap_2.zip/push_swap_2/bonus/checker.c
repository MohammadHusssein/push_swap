/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/23 15:36:01 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 17:31:34 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/checker.h"

void	ft_execute(t_stacks *stacks, char *op)
{
	if (!ft_strncmp(op, "ra\n", 3))
		ft_ra_checker(stacks);
	else if (!ft_strncmp(op, "rb\n", 3))
		ft_rb_checker(stacks);
	else if (!ft_strncmp(op, "rr\n", 3))
		ft_rr_checker(stacks);
	else if (!ft_strncmp(op, "rra\n", 4))
		ft_rra_checker(stacks);
	else if (!ft_strncmp(op, "rrb\n", 4))
		ft_rrb_checker(stacks);
	else if (!ft_strncmp(op, "rrr\n", 4))
		ft_rrr_checker(stacks);
	else if (!ft_strncmp(op, "sa\n", 3))
		ft_sa_checker(stacks);
	else if (!ft_strncmp(op, "sb\n", 3))
		ft_sb_checker(stacks);
	else if (!ft_strncmp(op, "ss\n", 3))
		ft_ss_checker(stacks);
	else if (!ft_strncmp(op, "pa\n", 3))
		ft_pa_checker(stacks);
	else if (!ft_strncmp(op, "pb\n", 3))
		ft_pb_checker(stacks);
	else
		ft_free_stacks_op(stacks, op);
}

int	ft_stack_size(t_stack *stack)
{
	int		len;
	t_stack	*current;

	len = 0;
	current = stack;
	while (current != NULL)
	{
		current = current->next;
		len++;
	}
	return (len);
}

int	ft_check_sorted(t_stack *stack_a)
{
	t_stack	*current;

	current = stack_a;
	while (current->next != NULL)
	{
		if (current->value > current->next->value)
			return (0);
		current = current->next;
	}
	return (1);
}

void	ft_checker(t_stacks *stacks)
{
	char	*op;

	while (1)
	{
		op = get_next_line(0);
		if (op == NULL)
			break ;
		ft_execute(stacks, op);
		free(op);
	}
	if (ft_check_sorted(stacks->stack_a) && ft_stack_size(stacks->stack_b) == 0)
		write(1, "OK\n", 3);
	else
		write(1, "KO\n", 3);
}

int	main(int argc, char **argv)
{
	t_stacks	stacks;

	if (argc > 1)
	{
		ft_check_args(argc, argv);
		stacks.stack_a = ft_create_stack(argc, argv);
		stacks.stack_b = NULL;
		ft_check_dup(stacks.stack_a);
		ft_checker(&stacks);
		ft_free_stacks_checker(&stacks);
	}
	return (0);
}
