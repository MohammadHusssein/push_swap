/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_swap.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/23 16:33:30 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 16:39:31 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/checker.h"

void	ft_sa_checker(t_stacks *stacks)
{
	t_stack	*first;

	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL)
		return ;
	first = stacks->stack_a;
	stacks->stack_a = stacks->stack_a->next;
	first->next = stacks->stack_a->next;
	stacks->stack_a->next = first;
}

void	ft_sb_checker(t_stacks *stacks)
{
	t_stack	*first;

	if (stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	first = stacks->stack_b;
	stacks->stack_b = stacks->stack_b->next;
	first->next = stacks->stack_b->next;
	stacks->stack_b->next = first;
}

void	ft_ss_checker(t_stacks *stacks)
{
	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL
		|| stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	ft_sa_checker(stacks);
	ft_sb_checker(stacks);
}
