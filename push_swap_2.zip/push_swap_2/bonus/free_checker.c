/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free_checker.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 15:36:06 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 17:31:04 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

// Frees the split that is malloced during checking input
// and exits if necessary
void	ft_free_split_and_exit(char **split, int exitFlag)
{
	int		i;

	i = 0;
	while (split[i])
	{
		free(split[i]);
		i++;
	}
	free(split);
	if (exitFlag)
		exit(EXIT_FAILURE);
}

// Frees stacks
void	ft_free_stacks_checker(t_stacks *stacks)
{
	ft_free_nodes(stacks->stack_a);
	ft_free_nodes(stacks->stack_b);
}

void	ft_free_nodes(t_stack *stack)
{
	t_stack	*current;
	t_stack	*next;

	current = stack;
	while (current != NULL)
	{
		next = current->next;
		free(current);
		current = next;
	}
	stack = NULL;
}

void	ft_free_all_and_exit(char **split, t_stack *stack)
{
	ft_free_nodes(stack);
	ft_free_split_and_exit(split, 1);
}

void	ft_free_stacks_op(t_stacks *stacks, char *op)
{
	free(op);
	ft_free_stacks_checker(stacks);
	ft_error("Error\n");
}
