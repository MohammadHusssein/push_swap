/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   checker_rev_rotate.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/23 16:34:11 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 16:42:38 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/checker.h"

void	ft_rra_checker(t_stacks *stacks)
{
	t_stack	*last;
	t_stack	*prevlast;

	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL)
		return ;
	last = stacks->stack_a;
	prevlast = NULL;
	while (last->next != NULL)
	{
		prevlast = last;
		last = last->next;
	}
	prevlast->next = NULL;
	last->next = stacks->stack_a;
	stacks->stack_a = last;
}

void	ft_rrb_checker(t_stacks *stacks)
{
	t_stack	*last;
	t_stack	*prevlast;

	if (stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	last = stacks->stack_b;
	prevlast = NULL;
	while (last->next != NULL)
	{
		prevlast = last;
		last = last->next;
	}
	prevlast->next = NULL;
	last->next = stacks->stack_b;
	stacks->stack_b = last;
}

void	ft_rrr_checker(t_stacks *stacks)
{
	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL
		|| stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	ft_rra_checker(stacks);
	ft_rrb_checker(stacks);
}
