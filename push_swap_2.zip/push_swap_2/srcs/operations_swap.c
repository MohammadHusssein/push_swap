/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_swap.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 16:53:00 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:21 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_sa(t_stacks *stacks, int print)
{
	t_stack	*first;

	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL)
		return ;
	first = stacks->stack_a;
	stacks->stack_a = stacks->stack_a->next;
	first->next = stacks->stack_a->next;
	stacks->stack_a->next = first;
	if (print)
		write(1, "sa\n", 3);
}

void	ft_sb(t_stacks *stacks, int print)
{
	t_stack	*first;

	if (stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	first = stacks->stack_b;
	stacks->stack_b = stacks->stack_b->next;
	first->next = stacks->stack_b->next;
	stacks->stack_b->next = first;
	if (print)
		write(1, "sb\n", 3);
}

void	ft_ss(t_stacks *stacks)
{
	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL
		|| stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	ft_sa(stacks, 0);
	ft_sb(stacks, 0);
	write(1, "ss\n", 3);
}
