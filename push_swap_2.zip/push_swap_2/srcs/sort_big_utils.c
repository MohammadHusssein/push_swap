/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_big_utils.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/19 13:20:34 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:15 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_update_extremums(t_stacks *stacks, int stack)
{
	if (stack == 1 && stacks->stack_a != NULL)
	{
		ft_update_min_a(stacks);
		ft_update_max_a(stacks);
	}
	else if (stack == 2 && stacks->stack_b != NULL)
	{
		ft_update_min_b(stacks);
		ft_update_max_b(stacks);
	}
	else
		return ;
}

void	ft_calculate_cheapest(t_stacks *stacks)
{
	t_stack	*current;
	int		i;

	current = stacks->stack_a;
	i = 0;
	while (current != NULL)
	{
		ft_price_to_top_a(stacks, i);
		if (current->value > stacks->extremums->max_b
			|| current->value < stacks->extremums->min_b)
			ft_new_extremum_price(stacks);
		else
			ft_price_in_b(stacks, current->value);
		ft_optimise_moves(stacks);
		ft_check_cost(stacks, i);
		current = current->next;
		i++;
	}
}

void	ft_move_cheapest(t_stacks *stacks)
{
	while (stacks->cheapest->ra-- != 0)
		ft_ra(stacks, 1);
	while (stacks->cheapest->rb-- != 0)
		ft_rb(stacks, 1);
	while (stacks->cheapest->rr-- != 0)
		ft_rr(stacks);
	while (stacks->cheapest->rra-- != 0)
		ft_rra(stacks, 1);
	while (stacks->cheapest->rrb-- != 0)
		ft_rrb(stacks, 1);
	while (stacks->cheapest->rrr-- != 0)
		ft_rrr(stacks);
	while (stacks->cheapest->pb-- != 0)
		ft_pb(stacks);
}
