/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_small.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 18:12:38 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 17:40:42 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_sort_three(t_stacks *stacks)
{
	t_stack	*current;

	current = stacks->stack_a;
	if (current->value > current->next->value)
	{
		if (current->value < current->next->next->value)
			ft_sa(stacks, 1);
		else if (current->next->value > current->next->next->value)
		{
			ft_sa(stacks, 1);
			ft_rra(stacks, 1);
		}
		else
			ft_ra(stacks, 1);
	}
	else
	{
		if (current->value > current->next->next->value)
			ft_rra(stacks, 1);
		else if (current->next->value > current->next->next->value)
		{
			ft_sa(stacks, 1);
			ft_ra(stacks, 1);
		}
	}
}

void	ft_sort_four(t_stacks *stacks)
{
	int	min_pos;

	min_pos = ft_min_pos(stacks->stack_a);
	ft_push_pos(stacks, &(stacks->stack_a), min_pos);
	ft_pb(stacks);
	ft_sort_three(stacks);
	ft_pa(stacks);
}

void	ft_sort_five(t_stacks *stacks)
{
	int	min_pos;

	min_pos = ft_min_pos(stacks->stack_a);
	ft_push_pos(stacks, &(stacks->stack_a), min_pos);
	ft_pb(stacks);
	min_pos = ft_min_pos(stacks->stack_a);
	ft_push_pos(stacks, &(stacks->stack_a), min_pos);
	ft_pb(stacks);
	ft_sort_three(stacks);
	ft_pa(stacks);
	ft_pa(stacks);
}
