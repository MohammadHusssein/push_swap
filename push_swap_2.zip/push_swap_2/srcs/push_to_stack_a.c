/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_to_stack_a.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/21 14:41:48 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:17 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_do_moves_adjust(t_stacks *stacks)
{
	while (stacks->moves->ra-- != 0)
		ft_ra(stacks, 1);
	while (stacks->moves->rra-- != 0)
		ft_rra(stacks, 1);
}

void	ft_adjust_stack(t_stacks *stacks)
{
	int	min_pos;
	int	len;

	stacks->moves->ra = 0;
	stacks->moves->rra = 0;
	if (stacks->stack_a->value != stacks->extremums->min_a)
	{
		min_pos = ft_find_pos_a(stacks, stacks->extremums->min_a);
		len = ft_stack_size(stacks->stack_a);
		if (len % 2 == 0)
		{
			if (min_pos < len / 2)
				stacks->moves->ra = min_pos;
			else
				stacks->moves->rra = len - min_pos;
		}
		else
		{
			if (min_pos <= len / 2)
				stacks->moves->ra = min_pos;
			else
				stacks->moves->rra = len - min_pos;
		}
	}
	ft_do_moves_adjust(stacks);
}

void	ft_push_to_stack_a(t_stacks *stacks)
{
	while (stacks->stack_b != NULL)
	{
		ft_update_extremums(stacks, 1);
		if (stacks->stack_b->value < stacks->extremums->min_a)
			ft_new_min_a(stacks);
		else if (stacks->stack_b->value > stacks->extremums->max_a)
			ft_new_max_a(stacks);
		else
			ft_new_element_a(stacks, stacks->stack_b);
	}
	ft_update_extremums(stacks, 1);
	ft_adjust_stack(stacks);
}
