/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   update_extremums.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/19 13:38:14 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:01 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_update_min_a(t_stacks *stacks)
{
	t_stack	*current;

	current = stacks->stack_a;
	stacks->extremums->min_a = current->value;
	while (current != NULL)
	{
		if (current->value < stacks->extremums->min_a)
			stacks->extremums->min_a = current->value;
		current = current->next;
	}
}

void	ft_update_max_a(t_stacks *stacks)
{
	t_stack	*current;

	current = stacks->stack_a;
	stacks->extremums->max_a = current->value;
	while (current != NULL)
	{
		if (current->value > stacks->extremums->max_a)
			stacks->extremums->max_a = current->value;
		current = current->next;
	}
}

void	ft_update_min_b(t_stacks *stacks)
{
	t_stack	*current;

	current = stacks->stack_b;
	stacks->extremums->min_b = current->value;
	while (current != NULL)
	{
		if (current->value < stacks->extremums->min_b)
			stacks->extremums->min_b = current->value;
		current = current->next;
	}
}

void	ft_update_max_b(t_stacks *stacks)
{
	t_stack	*current;

	current = stacks->stack_b;
	stacks->extremums->max_b = current->value;
	while (current != NULL)
	{
		if (current->value > stacks->extremums->max_b)
			stacks->extremums->max_b = current->value;
		current = current->next;
	}
}
