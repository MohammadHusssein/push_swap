/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   new_extremum_a.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/21 15:07:02 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:30 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_do_moves_a(t_stacks *stacks, int maxflag)
{
	while (stacks->moves->ra-- != 0)
		ft_ra(stacks, 1);
	while (stacks->moves->rra-- != 0)
		ft_rra(stacks, 1);
	ft_pa(stacks);
	if (maxflag)
		ft_ra(stacks, 1);
}

int	ft_find_pos_a(t_stacks *stacks, int value)
{
	t_stack	*current;
	int		i;

	i = 0;
	current = stacks->stack_a;
	while (current != NULL)
	{
		if (current->value == value)
			break ;
		current = current->next;
		i++;
	}
	return (i);
}

void	ft_new_min_a(t_stacks *stacks)
{
	int	min_pos;
	int	len;

	stacks->moves->ra = 0;
	stacks->moves->rra = 0;
	if (stacks->stack_a->value != stacks->extremums->min_a)
	{
		min_pos = ft_find_pos_a(stacks, stacks->extremums->min_a);
		len = ft_stack_size(stacks->stack_a);
		if (len % 2 == 0)
		{
			if (min_pos < len / 2)
				stacks->moves->ra = min_pos;
			else
				stacks->moves->rra = len - min_pos;
		}
		else
		{
			if (min_pos <= len / 2)
				stacks->moves->ra = min_pos;
			else
				stacks->moves->rra = len - min_pos;
		}
	}
	ft_do_moves_a(stacks, 0);
}

t_stack	*ft_last_node(t_stack *stack)
{
	t_stack	*current;

	current = stack;
	while (current->next != NULL)
		current = current->next;
	return (current);
}

void	ft_new_max_a(t_stacks *stacks)
{
	int	max_pos;
	int	len;

	stacks->moves->ra = 0;
	stacks->moves->rra = 0;
	if (ft_last_node(stacks->stack_a)->value != stacks->extremums->max_a)
	{
		max_pos = ft_find_pos_a(stacks, stacks->extremums->max_a);
		len = ft_stack_size(stacks->stack_a);
		if (len % 2 == 0)
		{
			if (max_pos < len / 2)
				stacks->moves->ra = max_pos + 1;
			else
				stacks->moves->rra = len - max_pos - 1;
		}
		else
		{
			if (max_pos <= len / 2)
				stacks->moves->ra = max_pos + 1;
			else
				stacks->moves->rra = len - max_pos - 1;
		}
	}
	ft_do_moves_a(stacks, 1);
}
