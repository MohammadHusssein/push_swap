/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_push.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 17:27:17 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:28 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_pa(t_stacks *stacks)
{
	t_stack	*tmp;

	if (stacks->stack_b == NULL)
		return ;
	tmp = stacks->stack_a;
	stacks->stack_a = stacks->stack_b;
	stacks->stack_b = stacks->stack_b->next;
	stacks->stack_a->next = tmp;
	write(1, "pa\n", 3);
}

void	ft_pb(t_stacks *stacks)
{
	t_stack	*tmp;

	if (stacks->stack_a == NULL)
		return ;
	tmp = stacks->stack_b;
	stacks->stack_b = stacks->stack_a;
	stacks->stack_a = stacks->stack_a->next;
	stacks->stack_b->next = tmp;
	write(1, "pb\n", 3);
}
