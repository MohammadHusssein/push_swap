/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_big.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 18:47:27 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 17:57:59 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_find_and_move_cheapest(t_stacks *stacks)
{
	t_moves		*moves;
	t_moves		*cheapest;
	t_extremums	*extremums;

	moves = (t_moves *)malloc(sizeof(t_moves));
	cheapest = (t_moves *)malloc(sizeof(t_moves));
	extremums = (t_extremums *)malloc(sizeof(t_extremums));
	if (!moves || !cheapest || !extremums)
		return ;
	ft_memset(moves, 0, sizeof(t_moves));
	ft_memset(cheapest, 0, sizeof(t_moves));
	ft_memset(extremums, 0, sizeof(t_extremums));
	stacks->moves = moves;
	stacks->cheapest = cheapest;
	stacks->extremums = extremums;
	while (ft_stack_size(stacks->stack_a) != 3)
	{
		ft_update_extremums(stacks, 2);
		ft_calculate_cheapest(stacks);
		ft_move_cheapest(stacks);
	}
}

void	ft_sort_big(t_stacks *stacks)
{
	ft_pb(stacks);
	ft_pb(stacks);
	ft_find_and_move_cheapest(stacks);
	ft_sort_three(stacks);
	ft_push_to_stack_a(stacks);
	free(stacks->cheapest);
	free(stacks->extremums);
	free(stacks->moves);
}
