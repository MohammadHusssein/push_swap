/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   new_element_a.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/21 15:19:28 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:34 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

int	ft_search_a(t_stacks *stacks, int value)
{
	t_stack	*current;
	int		flag;

	flag = 0;
	current = stacks->stack_a;
	while (flag == 0)
	{
		value++;
		while (current != NULL)
		{
			if (current->value == value)
				flag = 1;
			current = current->next;
		}
		current = stacks->stack_a;
	}
	return (value);
}

void	ft_new_element_a(t_stacks *stacks, t_stack *head_b)
{
	int	pos;
	int	len;

	stacks->moves->ra = 0;
	stacks->moves->rra = 0;
	if (stacks->stack_a->value != ft_search_a(stacks, head_b->value))
	{
		pos = ft_find_pos_a(stacks, ft_search_a(stacks, head_b->value));
		len = ft_stack_size(stacks->stack_a);
		if (len % 2 == 0)
		{
			if (pos < len / 2)
				stacks->moves->ra = pos;
			else
				stacks->moves->rra = len - pos;
		}
		else
		{
			if (pos <= len / 2)
				stacks->moves->ra = pos;
			else
				stacks->moves->rra = len - pos;
		}
	}
	ft_do_moves_a(stacks, 0);
}
