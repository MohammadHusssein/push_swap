/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations_rotate.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 17:52:39 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:24 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_ra(t_stacks *stacks, int print)
{
	t_stack	*last;

	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL)
		return ;
	last = stacks->stack_a;
	while (last->next != NULL)
		last = last->next;
	last->next = stacks->stack_a;
	stacks->stack_a = stacks->stack_a->next;
	last->next->next = NULL;
	if (print)
		write(1, "ra\n", 3);
}

void	ft_rb(t_stacks *stacks, int print)
{
	t_stack	*last;

	if (stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	last = stacks->stack_b;
	while (last->next != NULL)
		last = last->next;
	last->next = stacks->stack_b;
	stacks->stack_b = stacks->stack_b->next;
	last->next->next = NULL;
	if (print)
		write(1, "rb\n", 3);
}

void	ft_rr(t_stacks *stacks)
{
	if (stacks->stack_a == NULL || stacks->stack_a->next == NULL
		|| stacks->stack_b == NULL || stacks->stack_b->next == NULL)
		return ;
	ft_ra(stacks, 0);
	ft_rb(stacks, 0);
	write(1, "rr\n", 3);
}
