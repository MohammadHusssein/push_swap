/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_args.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 15:30:17 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:46 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

// Checks that every input contains only numbers, and
// if signs are encountered, makes sure they are followed
// by a number
int	ft_check_numeric(char *s)
{
	int	i;

	i = 0;
	while (s[i])
	{
		if ((s[i] < '0' || s[i] > '9') && s[i] != '+' && s[i] != '-')
			return (0);
		else if ((s[i] == '+' || s[i] == '-') && (s[i + 1] < '0'
				|| s[i + 1] > '9'))
			return (0);
		i++;
	}
	return (1);
}

// Checks that args are int, checks signs, check max and min int,
// but not duplicates
void	ft_parse_args(int argc, char **argv)
{
	int		i;
	char	**split;
	int		j;

	i = 1;
	while (i < argc)
	{
		split = ft_split(argv[i], ' ');
		if (split == NULL)
			ft_free_split_and_exit(split, 1);
		j = 0;
		while (split[j])
		{
			if (!ft_check_numeric(split[j]) || ft_atoll(split[j]) > MAXINT
				|| ft_atoll(split[j]) < MININT)
			{
				ft_free_split_and_exit(split, 0);
				ft_error("Error\n");
			}
			j++;
		}
		ft_free_split_and_exit(split, 0);
		i++;
	}
}

// checks argc count, then initiates the parsing
// (dup checking is not performed yet)
void	ft_check_args(int argc, char **argv)
{
	if (argc == 1)
		exit(EXIT_FAILURE);
	else if (argc > 1)
	{
		ft_parse_args(argc, argv);
	}
}
