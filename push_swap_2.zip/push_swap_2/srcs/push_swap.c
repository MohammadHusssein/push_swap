/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   push_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 15:26:00 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 17:33:38 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

int	main(int argc, char **argv)
{
	t_stacks	stacks;

	if (argc > 1)
	{
		ft_check_args(argc, argv);
		stacks.stack_a = ft_create_stack(argc, argv);
		stacks.stack_b = NULL;
		ft_check_dup(stacks.stack_a);
		ft_sort(&stacks);
		ft_free_stacks(&stacks);
	}
	return (0);
}
