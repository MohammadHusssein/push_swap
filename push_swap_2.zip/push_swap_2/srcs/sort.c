/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 16:11:49 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:07 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

int	ft_check_sorted(t_stack *stack_a)
{
	t_stack	*current;

	current = stack_a;
	while (current->next != NULL)
	{
		if (current->value > current->next->value)
			return (0);
		current = current->next;
	}
	return (1);
}

void	ft_sort(t_stacks *stacks)
{
	if (ft_check_sorted(stacks->stack_a))
		return ;
	else if (ft_stack_size(stacks->stack_a) == 2)
		ft_sa(stacks, 1);
	else if (ft_stack_size(stacks->stack_a) == 3)
		ft_sort_three(stacks);
	else if (ft_stack_size(stacks->stack_a) == 4)
		ft_sort_four(stacks);
	else if (ft_stack_size(stacks->stack_a) == 5)
		ft_sort_five(stacks);
	else
		ft_sort_big(stacks);
}
