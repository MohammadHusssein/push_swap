/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   calculate_cheapest.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/21 13:10:16 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:48 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_price_to_top_a(t_stacks *stacks, int pos)
{
	int	len;

	stacks->moves->pb = 1;
	stacks->moves->ra = 0;
	stacks->moves->rra = 0;
	if (pos == 0)
		return ;
	len = ft_stack_size(stacks->stack_a);
	if (len % 2 == 0)
	{
		if (pos < len / 2)
			stacks->moves->ra = pos;
		else
			stacks->moves->rra = len - pos;
	}
	else
	{
		if (pos <= len / 2)
			stacks->moves->ra = pos;
		else
			stacks->moves->rra = len - pos;
	}
}

int	ft_find_pos_b(t_stacks *stacks, int value)
{
	t_stack	*current;
	int		i;

	i = 0;
	current = stacks->stack_b;
	while (current != NULL)
	{
		if (current->value == value)
			break ;
		current = current->next;
		i++;
	}
	return (i);
}

void	ft_new_extremum_price(t_stacks *stacks)
{
	int	max_pos;
	int	len;

	stacks->moves->rb = 0;
	stacks->moves->rrb = 0;
	if (stacks->stack_b->value == stacks->extremums->max_b)
		return ;
	max_pos = ft_find_pos_b(stacks, stacks->extremums->max_b);
	len = ft_stack_size(stacks->stack_b);
	if (len % 2 == 0)
	{
		if (max_pos < len / 2)
			stacks->moves->rb = max_pos;
		else
			stacks->moves->rrb = len - max_pos;
	}
	else
	{
		if (max_pos <= len / 2)
			stacks->moves->rb = max_pos;
		else
			stacks->moves->rrb = len - max_pos;
	}
}

int	ft_search_b(t_stacks *stacks, int value)
{
	t_stack	*current;
	int		flag;

	flag = 0;
	current = stacks->stack_b;
	while (flag == 0)
	{
		value--;
		while (current != NULL)
		{
			if (current->value == value)
				flag = 1;
			current = current->next;
		}
		current = stacks->stack_b;
	}
	return (value);
}

void	ft_price_in_b(t_stacks *stacks, int value)
{
	int	pos;
	int	len;
	int	num;

	stacks->moves->rb = 0;
	stacks->moves->rrb = 0;
	num = ft_search_b(stacks, value);
	if (stacks->stack_b->value == num)
		return ;
	pos = ft_find_pos_b(stacks, num);
	len = ft_stack_size(stacks->stack_b);
	if (len % 2 == 0)
	{
		if (pos < len / 2)
			stacks->moves->rb = pos;
		else
			stacks->moves->rrb = len - pos;
	}
	else
	{
		if (pos <= len / 2)
			stacks->moves->rb = pos;
		else
			stacks->moves->rrb = len - pos;
	}
}
