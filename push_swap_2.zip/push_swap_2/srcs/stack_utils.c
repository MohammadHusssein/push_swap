/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   stack_utils.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 15:57:18 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:06 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	ft_putnbr_fd(int n, int fd)
{
	char	c;

	if (n == -2147483648)
	{
		write(fd, "-2147483648", 11);
		return ;
	}
	if (n < 0)
	{
		write(fd, "-", 1);
		n = -n;
	}
	if (n > 9)
		ft_putnbr_fd(n / 10, fd);
	c = (n % 10) + '0';
	write(fd, &c, 1);
}

void	ft_print_stack(t_stack *stack)
{
	t_stack	*current;

	current = stack;
	printf("\n\n");
	while (current != NULL)
	{
		ft_putnbr_fd(current->value, 1);
		write(1, "\n", 1);
		current = current->next;
	}
	printf("\n\n");
}

int	ft_stack_size(t_stack *stack)
{
	int		len;
	t_stack	*current;

	len = 0;
	current = stack;
	while (current != NULL)
	{
		current = current->next;
		len++;
	}
	return (len);
}
