/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_small_utils.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mohhusse <mohhusse@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/15 18:23:27 by mohhusse          #+#    #+#             */
/*   Updated: 2024/08/23 15:41:11 by mohhusse         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

int	ft_min_pos(t_stack *stack)
{
	t_stack	*current;
	int		min_val;
	int		min_pos;
	int		pos;

	current = stack;
	min_val = current->value;
	min_pos = 0;
	pos = 0;
	while (current)
	{
		if (current->value < min_val)
		{
			min_val = current->value;
			min_pos = pos;
		}
		current = current->next;
		pos++;
	}
	return (min_pos);
}

void	ft_push_pos(t_stacks *stacks, t_stack **stack_a, int pos)
{
	int	len;

	len = ft_stack_size(*stack_a);
	if (pos <= len / 2)
		while (pos--)
			ft_ra(stacks, 1);
	else
	{
		pos = len - pos;
		while (pos--)
			ft_rra(stacks, 1);
	}
}
